/*
####################################
#### Aryan Agarwal, 19CS30005   ####
#### Vinit Raj, 19CS10065       ####
#### CS39003 -> Assignment 6    ####
####################################
*/

#ifndef MYL_H
#define MYL_H

#define ERR 1
#define OK 0

int printStr(char *);
int printInt(int);
int readInt(int *);

#endif