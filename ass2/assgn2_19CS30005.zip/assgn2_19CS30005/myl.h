/*
####################################
#### Aryan Agarwal              ####   
#### 19CS30005                  ####
#### CS39003 -> Assignment 2    ####
####################################
*/


#ifndef MYL_H
#define MYL_H

#define ERR 0
#define OK 1

int printStr(char *);
int printInt(int);
int readInt(int *);
int readFlt(float *);
int printFlt(float);

#endif
